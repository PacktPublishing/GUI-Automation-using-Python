#!/usr/bin/env python
# coding: utf-8

# In[ ]:


cd C:\GUI_Automation\BeautifulSoup


# In[ ]:


from bs4 import BeautifulSoup

with open('generic_simple.html') as html_file:
    soup = BeautifulSoup(html_file)


# In[ ]:





# In[ ]:


# Understand the object - Soup
print(dir(soup))


# In[ ]:


# Python's help utility
print(help(soup))


# In[ ]:





# In[ ]:





# In[ ]:


from bs4 import BeautifulSoup

with open('generic_simple.html') as html_file:
   soup = BeautifulSoup(html_file)

#Display the html content
print(soup)


# In[ ]:





# In[ ]:


#to look at nested structure of HTML page
print( soup.prettify() )


# In[ ]:


print(soup.get_text())


# In[ ]:





# In[ ]:


# soup.tagName: 
# Return content between opening and closing tag including tag.
print("Result of soup.title :" , soup.title)


# In[ ]:


# soup.<tag>.string: 
# Return string within given tag
print("Result of soup.title.string :" , soup.title.string)


# In[ ]:


print("Result of soup.title.name :" , soup.title.name)


# In[ ]:


print("Result of soup.title.parent.name :" , soup.title.parent.name)


# In[ ]:


print("Result of soup.title.parent.name :" , soup.title.parent.parent.name)


# In[ ]:





# In[ ]:


#Converting the output to list
print(   list(soup.html.div.children)   )


# In[ ]:





# In[ ]:


#Or we can iterate over the list
for i in soup.html.div.children:
    print(i.name)    # Printing the tag name


# In[ ]:





# In[ ]:


print("Result of soup.p :" , soup.p)
print("Result of soup.p.string :" , soup.p.string)

print("--------------------------------------------")

print("Result of soup.a :" , soup.a)
print("Result of soup.a.href :" , soup.a.string)
print("--------------------------------------------")

print("Result of soup.div :" , soup.div)
print("Result of soup.div.string :" , soup.div.string)
print("--------------------------------------------")


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:


from bs4 import BeautifulSoup

with open('generic_simple.html') as html_file:
    soup = BeautifulSoup(html_file)


# In[ ]:





# In[ ]:


#find()
#Return only the first child of this Tag matching the given criteria.

soup.find('div')
#soup.div


# In[ ]:


print( soup.div )


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:


#Return first div element whose id is 'imp_article_ID'
soup.find('div', id='imp_article_ID') 


# In[ ]:


#Return first element whose id is 'imp_article_ID'
soup.find(id='imp_article_ID')


# In[ ]:





# In[ ]:





# In[ ]:


#Return first element whose id is 'contact'
soup.find(id="contact")


# In[ ]:


#Return text of first element whose id is 'contact'
soup.find(id="contact").text


# In[ ]:





# In[ ]:





# In[ ]:


#Return first div element whose class attribute is 'article'
soup.find('div', class_='article')


# In[ ]:


#Return first div element whose class attribute is 'article'
soup.find('div', attrs={'class':'article'})


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:


#Return all div element whose class attribute is 'article'
soup.find_all('div', attrs={'class':'article'})


# In[ ]:


soup.find_all('div') 


# In[ ]:





# In[ ]:


print(soup.find_all('a'))


# In[ ]:


for link in soup.find_all('a'):
    print(link.get('href'))


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:


from bs4 import BeautifulSoup

with open('data_in_table.html') as html_file:
   soup = BeautifulSoup(html_file)


# In[ ]:





# In[ ]:


from bs4 import BeautifulSoup

with open('data_in_table.html') as html_file:
   soup = BeautifulSoup(html_file)

table = soup.find(id='main_table')

table_rows= table.find_all('tr')
print(table_rows)


# In[ ]:





# In[ ]:





# In[ ]:


from bs4 import BeautifulSoup

with open('data_in_table.html') as html_file:
   soup = BeautifulSoup(html_file)

table = soup.find(id='main_table')

table_rows= table.find_all('tr')

marks_sheet=[]

for i in range(1, len(table_rows)):
    row = table_rows[i]
    tmp = row.find_all('td')
    student_id = tmp[0].text
    student_name = tmp[1].text
    student_grade = tmp[2].text
    marks_sheet.append([student_id,student_name,student_grade,'\n'])
    
print(marks_sheet)


# In[ ]:





# In[ ]:





# In[ ]:


#Second table
from bs4 import BeautifulSoup

with open('data_in_table_2.html') as html_file:
   soup = BeautifulSoup(html_file)

#table = soup.find_all('table')[1]
#table_rows= table.find_all('tr')

table_rows = soup.find_all('table')[1].find_all('tr')

student_interest=[]

for i in range(1, len(table_rows)):
    row = table_rows[i]
    tmp = row.find_all('td')
    course_title = tmp[0].text
    course_interest = tmp[1].text
    student_interest.append([course_title,course_interest, '\n'])
    
print(student_interest)


# In[ ]:





# In[ ]:





# In[ ]:


import requests


print( dir(requests) )


# In[ ]:





# In[ ]:





# In[ ]:


import requests


# In[ ]:


print(dir(page))


# In[ ]:


#page ( Check Status)
page.status_code


# In[ ]:





# In[ ]:


from bs4 import BeautifulSoup
import requests

page = requests.get('https://techsckool.com/courses/')

if( page.status_code == 200):
    print('OK')
    print(page.text)
else:
    print("HTTP Error Occurred. Error Code",page.status_code)


# In[ ]:





# In[ ]:





# In[ ]:


# Create a BeautifulSoup object
soup = BeautifulSoup(page.text)

print(soup.prettify())


# In[ ]:





# In[ ]:





# In[52]:


from bs4 import BeautifulSoup
import requests

page = requests.get('https://techsckool.com/courses/')

if( page.status_code == 200):
    
    soup = BeautifulSoup(page.text)
    
    for link in soup.find_all('a'):
        print(link.get('href'))
    
else:
    print("HTTP Error Occurred. Error Code",page.status_code)
