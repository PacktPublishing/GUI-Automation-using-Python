import pyautogui
import time

pyautogui.PAUSE = 1
pyautogui.FAILSAFE = True


#Opening the webpage
pyautogui.hotkey("win","r")  
pyautogui.typewrite("http://localhost/employee_portal/ \n")

# Giving time to browser for opening the page
time.sleep(10)  


#Webpage automation

emp_name="Emp ABC"
emp_id="1234567"
sex="female"
email="abc@TechSckool.com"
phone="9876789"

pyautogui.click(pyautogui.locateCenterOnScreen('img\\1_emp_name.png',confidence=0.9))   #Clicking on the textbox
pyautogui.typewrite(emp_name, interval=0.25)   #Typing inside textbox

pyautogui.click(pyautogui.locateCenterOnScreen('img\\2_emp_id.png',confidence=0.9))
pyautogui.typewrite(emp_id, interval=0.25)

pyautogui.click(pyautogui.locateCenterOnScreen('img\\3_emp_address.png',confidence=0.9))
pyautogui.typewrite(email, interval=0.25)

pyautogui.click(pyautogui.locateCenterOnScreen('img\\4_emp_phone.png',confidence=0.9))
pyautogui.typewrite(phone, interval=0.25)

pyautogui.click(pyautogui.locateCenterOnScreen('img\\5_drop_down.png',confidence=0.9))

if sex=='male':
    pyautogui.click(pyautogui.locateCenterOnScreen('img\\6_1_male.png',confidence=0.9))
else:
    pyautogui.click(pyautogui.locateCenterOnScreen('img\\6_2_female.png',confidence=0.9))


#Submitting the form
pyautogui.click(pyautogui.locateCenterOnScreen('img\\7_register.png',confidence=0.8))


pyautogui.alert(text='Job Completed Successfully', title='Data Entry System', button='OK')












