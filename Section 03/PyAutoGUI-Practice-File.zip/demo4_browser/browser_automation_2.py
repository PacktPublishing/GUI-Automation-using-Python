import pyautogui
import time

pyautogui.PAUSE = 1
pyautogui.FAILSAFE = True


#Opening the webpage
pyautogui.hotkey("win","r")  
pyautogui.typewrite("http://localhost/employee_portal/ \n")

# Giving time to browser for opening the page
time.sleep(10) 


#Webpage automation

with open("members.csv") as f:
    next(f)

    for line in f:
        line=line.strip()
        line=line.split(",")
        print("data entry started for: ",line)
        emp_name=line[0]
        emp_id=line[1]
        sex=line[2]
        email=line[3]
        phone=line[4]
		
        pyautogui.click(pyautogui.locateCenterOnScreen('img\\1_emp_name.png',confidence=0.8))   #Clicking on the textbox
        pyautogui.typewrite(emp_name, interval=0.25)   #Typing inside textbox

        pyautogui.click(pyautogui.locateCenterOnScreen('img\\2_emp_id.png',confidence=0.8))
        pyautogui.typewrite(emp_id, interval=0.25)

        pyautogui.click(pyautogui.locateCenterOnScreen('img\\3_emp_address.png',confidence=0.8))
        pyautogui.typewrite(email, interval=0.25)

        pyautogui.click(pyautogui.locateCenterOnScreen('img\\4_emp_phone.png',confidence=0.8))
        pyautogui.typewrite(phone, interval=0.25)

        pyautogui.click(pyautogui.locateCenterOnScreen('img\\5_drop_down.png',confidence=0.8))

        if sex=='male':
            pyautogui.click(pyautogui.locateCenterOnScreen('img\\6_1_male.png',confidence=0.8))
        else:
            pyautogui.click(pyautogui.locateCenterOnScreen('img\\6_2_female.png',confidence=0.8))


        #Submitting the form
        pyautogui.click(pyautogui.locateCenterOnScreen('img\\7_register.png',confidence=0.8))
        time.sleep(3)  #sleeping for 3 seconds in order to wait for form processing

pyautogui.alert(text='Job Completed Successfully', title='Data Entry System', button='OK')