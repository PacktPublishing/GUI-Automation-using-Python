import pyautogui


pyautogui.PAUSE = 1
pyautogui.FAILSAFE = True

#Clicking on the textbox
pyautogui.click(pyautogui.locateCenterOnScreen('text_box.png',confidence=0.6))


#Typing inside textbox
pyautogui.typewrite('Mr. XYZ ABC', interval=0.25)

#Submitting the form
pyautogui.click(pyautogui.locateCenterOnScreen('submit_button.png',confidence=0.8))

#Accepting the confirmation
pyautogui.click(pyautogui.locateCenterOnScreen('ok_button.png',confidence=0.8))

