import wx
import datetime

class Mywin(wx.Frame):
    def __init__(self, parent, title):
        super(Mywin, self).__init__(parent, title=title, size=(350, 250))

        panel = wx.Panel(self)
        vbox = wx.BoxSizer(wx.VERTICAL)

        hbox1 = wx.BoxSizer(wx.HORIZONTAL)
        l1 = wx.StaticText(panel, -1, "Employee Name")

        hbox1.Add(l1, 1, wx.EXPAND | wx.ALIGN_LEFT | wx.ALL, 5)
        self.t1 = wx.TextCtrl(panel)

        hbox1.Add(self.t1, 1, wx.EXPAND | wx.ALIGN_LEFT | wx.ALL, 5)
        vbox.Add(hbox1)

        #Submit Button
        submitButton = wx.Button(panel, label='Mark my attendance', pos=(100, 100))
        submitButton.Bind(wx.EVT_BUTTON, self.OnSubmit)
        self.SetSize((350, 250))
        self.SetTitle('Attendance Management')
        self.Centre()

        panel.SetSizer(vbox)

        self.Show()
        self.Fit()

    def OnSubmit(self, e):
        time = str(datetime.datetime.now())
        wx.MessageBox('Dear Employee, \n Your attendance is recorded successfully. \n Time: '+ time, 'Info', wx.OK | wx.ICON_INFORMATION)
        #self.Close(True)

app = wx.App()
Mywin(None, 'Advanced Attendance System')
app.MainLoop()