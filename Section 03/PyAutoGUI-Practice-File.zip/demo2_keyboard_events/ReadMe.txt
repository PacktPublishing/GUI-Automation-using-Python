In order to instll wxpython, execute below command:

pip install -U wxPython

From <https://wxpython.org/pages/downloads/> 

WxPython is not coded in Python
Used for creating windows and all other GUI components


