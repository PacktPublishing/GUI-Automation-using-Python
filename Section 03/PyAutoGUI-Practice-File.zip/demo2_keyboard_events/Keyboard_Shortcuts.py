import pyautogui

pyautogui.FAILSAFE = True

#To press keys
pyautogui.keyDown('ctrl')
pyautogui.keyDown('alt')
pyautogui.keyDown('tab')



#To lift keys
pyautogui.keyDown('ctrl')
pyautogui.keyDown('alt')
pyautogui.keyDown('tab')

#OR 

pyautogui.hotkey('ctrl', 'alt', 'tab')