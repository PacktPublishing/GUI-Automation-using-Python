import pyautogui


pyautogui.PAUSE = 1
pyautogui.FAILSAFE = True


#position of different button.
#Found using: pyautogui.displayMousePosition()
#Stored inside: Tuples
position_of_button_1 = (1483,853)
position_of_button_2 = (1608,853)
position_of_button_plus = (1836, 856)
position_of_button_8 = (1618, 651)
position_of_button_equals = (1842, 960)


# Start of Flow


#moving to button 1 and then clicking it
pyautogui.moveTo(position_of_button_1, duration=2)
pyautogui.click()

#Click button2
pyautogui.click(position_of_button_2)

#Click button_plus
pyautogui.click(position_of_button_plus)

#Click position_of_button_8     four times
pyautogui.click(position_of_button_8, clicks=4, interval=1)

#Click = to see results
pyautogui.click(position_of_button_equals)
