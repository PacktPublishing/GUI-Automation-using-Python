import wx


class Mywin(wx.Frame):
    def __init__(self, parent, title):
        super(Mywin, self).__init__(parent, title=title, size=(350, 250))

        panel = wx.Panel(self)
        vbox = wx.BoxSizer(wx.VERTICAL)

        hbox1 = wx.BoxSizer(wx.HORIZONTAL)
        l1 = wx.StaticText(panel, -1, "Name")

        hbox1.Add(l1, 1, wx.EXPAND | wx.ALIGN_LEFT | wx.ALL, 5)
        self.t1 = wx.TextCtrl(panel)

        hbox1.Add(self.t1, 1, wx.EXPAND | wx.ALIGN_LEFT | wx.ALL, 5)
        vbox.Add(hbox1)

        hbox2 = wx.BoxSizer(wx.HORIZONTAL)
        l2 = wx.StaticText(panel, -1, "Department")

        hbox2.Add(l2, 1, wx.ALIGN_LEFT | wx.ALL, 5)
        self.t2 = wx.TextCtrl(panel)
        self.t2.SetMaxLength(5)

        hbox2.Add(self.t2, 1, wx.EXPAND | wx.ALIGN_LEFT | wx.ALL, 5)
        vbox.Add(hbox2)
        self.t2.Bind(wx.EVT_TEXT_MAXLEN, self.OnMaxLen)

        hbox3 = wx.BoxSizer(wx.HORIZONTAL)
        l3 = wx.StaticText(panel, -1, "My Project")

        hbox3.Add(l3, 1, wx.EXPAND | wx.ALIGN_LEFT | wx.ALL, 5)
        self.t3 = wx.TextCtrl(panel, size=(200, 100), style=wx.TE_MULTILINE)

        hbox3.Add(self.t3, 1, wx.EXPAND | wx.ALIGN_LEFT | wx.ALL, 5)
        vbox.Add(hbox3)
        self.t3.Bind(wx.EVT_TEXT_ENTER, self.OnEnterPressed)

        #Submit Button
        closeButton = wx.Button(panel, label='Submit Details', pos=(150, 175))
        closeButton.Bind(wx.EVT_BUTTON, self.OnSubmit)
        self.SetSize((350, 250))
        self.SetTitle('New Employee Onboarding System')
        self.Centre()

        panel.SetSizer(vbox)

        self.Centre()
        self.Show()
        self.Fit()

    def OnSubmit(self, e):
        wx.MessageBox('Details Submitted Sucessfully', 'Info', wx.OK | wx.ICON_INFORMATION)
        self.Close(True)

    def OnEnterPressed(self, event):
        print("Enter pressed")

    def OnMaxLen(self, event):
        print("Maximum length reached")


app = wx.App()
Mywin(None, 'New Employee Onboarding')
app.MainLoop()