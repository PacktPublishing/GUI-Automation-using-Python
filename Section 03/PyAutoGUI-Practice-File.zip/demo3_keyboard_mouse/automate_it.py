import pyautogui

pyautogui.PAUSE = 2
pyautogui.FAILSAFE = True

name="Vijay"
dept="myDept"
project="This is employees project details: \n Employee will work in Server Managemnt team serve  our clients 24/7 model. \n Customer Satisfaction is our goal."


pyautogui.click(pyautogui.locateCenterOnScreen('img\\name.png',confidence=0.8))   #Clicking on the textbox
pyautogui.typewrite(name, interval=0.1)   #Typing inside textbox

pyautogui.click(pyautogui.locateCenterOnScreen('img\\dept.png',confidence=0.8))
pyautogui.typewrite(dept, interval=0.1)
		
pyautogui.click(pyautogui.locateCenterOnScreen('img\\project.png',confidence=0.8))
pyautogui.typewrite(project, interval=0.1)
				
pyautogui.confirm(text='Sir, I have completed the form. Should I submit it it?', title='Data Entry System', buttons=['Yes Please', 'No'])
				
pyautogui.click(pyautogui.locateCenterOnScreen('img\\submit.png',confidence=0.8))	
						
pyautogui.click(pyautogui.locateCenterOnScreen('img\\ok.png',confidence=0.8))

pyautogui.alert(text='Job Completed Successfully', title='Data Entry System', button='OK')